# Role Recognition System - Flow Diagram & Architecture

## Complete Role Recognition Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ USER LOGIN PROCESS                                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. User visits /auth/login                                     │
│     └─> Enters: f12x.studio@gmail.com / F12XMAGICFIT            │
│                                                                  │
│  2. Supabase Auth validates credentials                         │
│     └─> Checks auth.users table for email/password match       │
│     └─> Returns JWT token with user.id                         │
│                                                                  │
│  3. useAuth() hook runs in layout.tsx                           │
│     └─> Calls: supabase.auth.getUser()                         │
│     └─> Gets: { id: UUID, email: string, ... }                 │
│                                                                  │
│  4. useAuth() fetches profile data                              │
│     └─> Queries: SELECT * FROM profiles WHERE id = auth.uid()  │
│     └─> Checks RLS policy: (auth.uid() = id)                   │
│     └─> Returns: { role: 'editor' | 'client', ... }            │
│                                                                  │
│  5. setProfile() updates React state                            │
│     └─> profile.role = 'editor'                                 │
│                                                                  │
│  6. Header component renders                                    │
│     └─> isEditor = profile?.role === 'editor'                  │
│     └─> true → shows Settings menu                             │
│     └─> false → hides Settings menu                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Database Table Relationships

```
┌─────────────────────────┐
│    auth.users           │
├─────────────────────────┤
│ id (UUID) [PK]          │
│ email (string)          │←──── Source of Truth for Login
│ email_confirmed_at      │
│ encrypted_password      │
│ last_sign_in_at         │
└─────────────────────────┘
         │
         │ auth.uid() = profiles.id
         │
         ▼
┌─────────────────────────┐
│    profiles             │
├─────────────────────────┤
│ id (UUID) [PK, FK]      │←──── Must match auth.users.id
│ email (TEXT)            │←──── Should match auth.users.email
│ first_name (TEXT)       │
│ company_name (TEXT)     │
│ role (TEXT) ★★★         │←──── CRITICAL: 'editor'|'client'
│ is_active (BOOLEAN)     │
│ email_verified (BOOL)   │
│ created_at (TIMESTAMP)  │
│ updated_at (TIMESTAMP)  │
└─────────────────────────┘
         │
         │ Can access based on role
         │
         ├─────────────────────────────────────────────┐
         │                                             │
         ▼                                             ▼
    ┌──────────────┐                          ┌──────────────┐
    │  creators    │                          │  campaigns   │
    │  payouts     │                          │  messages    │
    │  engagements │                          │  approvals   │
    └──────────────┘                          └──────────────┘
```

## RLS Policy Chain for Role Recognition

```
┌──────────────────────────────────────────────────────────────┐
│ USER REQUESTS DATA (e.g., GET /creators)                     │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Request Header: Authorization: Bearer [JWT_TOKEN]           │
│                                                               │
│  ┌─ Supabase Auth checks JWT ─┐                             │
│  │ ✓ Valid → auth.uid() = UUID │                             │
│  │ ✗ Invalid → reject          │                             │
│  └──────────────────────────┬──┘                             │
│                             │                                 │
│  ┌─ RLS Policy Evaluates ──┴──┐                             │
│  │                            │                              │
│  │  SELECT * FROM creators    │                              │
│  │  WHERE ...                 │                              │
│  │    OR                      │                              │
│  │    (SELECT role            │                              │
│  │     FROM profiles          │                              │
│  │     WHERE id = auth.uid()) │  ← ROLE LOOKUP              │
│  │    IN ('admin', 'editor')  │                              │
│  │                            │                              │
│  └────────────┬───────────────┘                             │
│               │                                              │
│      ┌────────┴────────┐                                     │
│      │                 │                                     │
│      ▼                 ▼                                     │
│   ✓ Role is        ✗ Role is                                │
│     editor           client                                 │
│   ✓ Return all    ✗ Return only                             │
│     creators        approved                                │
│                    creators                                 │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

## Component Access Based on Role

```
EDITOR (f12x.studio@gmail.com)
│
├─ Dashboard ─────────── ✓ Full access
├─ Creators Gallery ───── ✓ See all + edit
├─ Analytics ──────────── ✓ Full access
├─ Timeline ───────────── ✓ Full access
├─ Calendar ───────────── ✓ Full access
├─ Messages ───────────── ✓ Full access
├─ Reports ────────────── ✓ Full access
└─ Settings ───────────── ✓ VISIBLE (editor-only)
   ├─ User Management ─── ✓
   ├─ Campaign Settings ─ ✓
   ├─ Approval Rules ──── ✓
   └─ Integrations ────── ✓


CLIENT (sheik.farooq@pushowl.com)
│
├─ Dashboard ─────────── ✓ Limited view
├─ Creators Gallery ───── ✓ Approved only
├─ Analytics ──────────── ✓ Limited metrics
├─ Timeline ───────────── ✗ No access (RLS blocks)
├─ Calendar ───────────── ✗ No access (RLS blocks)
├─ Messages ───────────── ✗ No access (RLS blocks)
├─ Reports ────────────── ✓ Limited reports
└─ Settings ───────────── ✗ HIDDEN (not in nav)
```

## How Role is Determined (Simplified)

```javascript
// In useAuth() hook
const profile = await supabase
  .from('profiles')
  .select('*')
  .eq('id', user.id)        // ← Find profile by user ID
  .single();

// profile.role = 'editor' | 'client' | 'admin'

// In Header component
const isEditor = profile?.role === 'editor' || profile?.role === 'admin';

// Conditionally render
{isEditor && <SettingsLink />}  // Only shows if true
```

## Critical Requirements Met

| Requirement | Status | How |
|------------|--------|-----|
| User Login | ✓ | Supabase Auth validates email/password |
| Profile Fetch | ✓ | useAuth queries profiles table by id |
| Role Reading | ✓ | profile.role field populated |
| RLS Enforcement | ✓ | Policies check role before returning data |
| UI Conditional | ✓ | Header checks isEditor from profile.role |
| Email Consistency | ✓ | Both auth.users.email and profiles.email stored |

## Debugging Checklist

```
☐ auth.users table has 3 users
☐ profiles table has 3 records
☐ profiles.id matches auth.users.id for each user
☐ profiles.email matches auth.users.email (case matters!)
☐ profiles.role is 'editor', 'client', or 'admin'
☐ RLS policies exist on profiles table
☐ useAuth() hook successfully queries profiles
☐ profile object is populated with role data
☐ Header component receives non-null profile
☐ isEditor derived correctly from profile.role
```

## Success Indicators

When everything works:
1. Login with editor email → Header shows "👨‍💼 Editor"
2. Settings menu appears in navigation
3. Can access all admin features
4. Login with client email → Header shows "👤 Client"
5. Settings menu hidden from navigation
6. Limited to approved data only
