# Deployment and Setup Guide

## Pre-Deployment Checklist

### Supabase Setup
- [ ] Supabase project created
- [ ] PostgreSQL database provisioned
- [ ] Auth configured and enabled
- [ ] Database tables created (migration 001)
- [ ] RLS policies enabled on all tables
- [ ] Service role key stored securely
- [ ] Anon key configured for client

### Application Setup
- [ ] Environment variables configured in Vercel
- [ ] `NEXT_PUBLIC_SUPABASE_URL` set
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` set
- [ ] `SUPABASE_SERVICE_ROLE_KEY` set
- [ ] Database connection strings set
- [ ] `googleapis` package removed from dependencies
- [ ] All Google Sheets references removed from code

### Security Review
- [ ] All RLS policies reviewed
- [ ] No hardcoded credentials in code
- [ ] Error messages don't expose sensitive info
- [ ] API rate limiting configured
- [ ] CORS properly configured

### Testing
- [ ] User login with all three test accounts works
- [ ] Creator creation and edit works
- [ ] Bulk import processes CSV correctly
- [ ] Pagination works correctly
- [ ] Filtering and sorting functions properly
- [ ] Payout status updates work
- [ ] Error handling shows graceful messages

## Step-by-Step Deployment

### 1. Create Supabase Project

Visit [supabase.com](https://supabase.com) and create a new project:

```
Project Name: F12X Magicfit Dashboard
Database Name: f12x_magicfit
Region: Choose closest to your users
```

### 2. Execute Database Migration

Once Supabase project is created:

1. Go to SQL Editor in Supabase dashboard
2. Create new query
3. Copy entire contents of `/supabase/migrations/001_create_tables.sql`
4. Execute the SQL

This will:
- Create all 6 tables
- Set up indexes for performance
- Enable RLS on all tables
- Create all RLS policies
- Set up automatic timestamp triggers

### 3. Initialize User Accounts

Option A: Run setup script
```bash
# Install dependencies first
pnpm install

# Run setup script
npx ts-node scripts/setup-database.ts
```

Option B: Manual creation via Supabase Auth UI
1. Go to Authentication > Users in Supabase
2. Invite user: f12x.studio@gmail.com (role: editor)
3. Invite user: sheik.farooq@pushowl.com (role: client)
4. Invite user: ajayracharla20001@gmail.com (role: editor)
5. Each user will receive email to set password

### 4. Configure Environment Variables

In Vercel project settings, add these environment variables:

```
NEXT_PUBLIC_SUPABASE_URL=https://[project-id].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
POSTGRES_URL=postgresql://postgres:[password]@[host]:[port]/postgres
POSTGRES_PRISMA_URL=postgresql://postgres:[password]@[host]:[port]/postgres
POSTGRES_URL_NON_POOLING=postgresql://postgres:[password]@[host]:[port]/postgres
POSTGRES_USER=postgres
POSTGRES_PASSWORD=[your-password]
POSTGRES_HOST=[your-host]
POSTGRES_PORT=5432
POSTGRES_DATABASE=postgres
```

To find these values:
1. Go to Supabase project settings > Database
2. Copy connection string and parse values
3. For service role key, go to Settings > API > Project API keys

### 5. Remove Google Sheets Dependencies

Already done in the revised version:
- `googleapis` package removed from package.json
- `/lib/google-sheets/` directory deleted
- All Google Sheets imports removed from pages

Verify nothing is left:
```bash
# Should return no results
grep -r "googleapis" .
grep -r "google-sheets" .
grep -r "fetchCreators" .
```

### 6. Deploy to Vercel

```bash
# Verify build works locally
pnpm build

# If build successful, push to GitHub
git add .
git commit -m "chore: remove Google Sheets, use Supabase only"
git push origin main

# Vercel will auto-deploy
```

### 7. Post-Deployment Verification

Once deployed:

1. **Test Authentication**
   - Navigate to `/auth/login`
   - Login with each test account
   - Verify role-based dashboard access

2. **Test Creator Data**
   - Go to `/dashboard/creators`
   - Verify creators display
   - Test filtering and sorting
   - Test pagination

3. **Test Bulk Import**
   - Prepare sample CSV with these columns:
     ```
     creator_name,platform,deliverable,approval_status,progress_score,live_date,video_link,published_video_link,views,engagement_rate,followers,total_reach,spend
     ```
   - Upload file via dashboard
   - Verify import completes and data appears

4. **Test Payout Management**
   - Create test payouts in Supabase directly
   - Verify editors can view payout status
   - Test payout status updates

### 8. Production Optimizations

#### Database Optimization
```sql
-- Analyze tables for query planner
ANALYZE creators;
ANALYZE payouts;
ANALYZE campaigns;

-- Monitor slow queries
SELECT query, mean_time, calls
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 10;
```

#### Performance Tuning
1. Monitor Lighthouse scores
2. Check Core Web Vitals in Vercel Analytics
3. Review bundle size with `next/bundle-analyzer`
4. Optimize images with next/image

#### Security Hardening
1. Set CORS headers appropriately
2. Configure rate limiting on API routes
3. Set up DDoS protection
4. Enable HSTS headers
5. Regular security audits of RLS policies

## Monitoring and Maintenance

### Daily
- Monitor error logs in application
- Check deployment status in Vercel
- Verify critical features working

### Weekly
- Review database performance metrics
- Check for failed bulk imports
- Monitor authentication failures
- Review user activity logs

### Monthly
- Analyze query performance
- Review and update RLS policies if needed
- Archive old bulk import records
- Security patches and updates

### Quarterly
- Full security audit
- Performance optimization review
- Database optimization
- Capacity planning

## Rollback Procedure

If issues occur after deployment:

### Quick Rollback (Vercel)
1. Go to Vercel Dashboard
2. Go to Deployments
3. Click on previous successful deployment
4. Click "Promote to Production"

### Database Rollback
If database changes went wrong:

1. Create snapshot from Supabase dashboard
2. Restore from snapshot
3. Re-run failed migration
4. Verify data integrity

## Troubleshooting

### Login Not Working
1. Verify Supabase Auth is enabled
2. Check environment variables are set
3. Verify user exists in profiles table
4. Check RLS policies on profiles table

### Creator Data Not Showing
1. Verify getCreators() is being called
2. Check RLS policy allows user access
3. Verify creators table has data
4. Check browser console for errors

### Bulk Import Failing
1. Verify CSV format is correct
2. Check all required columns present
3. Review error_log in bulk_imports table
4. Verify user has editor role

### Performance Issues
1. Check database query times
2. Verify indexes are created
3. Monitor connection pool usage
4. Review cache hit rates
5. Optimize N+1 query patterns

## Support and Documentation

- **Supabase Docs:** https://supabase.com/docs
- **Next.js Docs:** https://nextjs.org/docs
- **Vercel Docs:** https://vercel.com/docs
- **PostgreSQL Docs:** https://www.postgresql.org/docs/

## Disaster Recovery

### Data Backup
Supabase automatically backs up your database:
- Daily automated backups
- Point-in-time recovery available
- Manual backups can be exported

### Recovery Procedure
1. Go to Supabase Dashboard > Backups
2. Select restore point
3. Confirm recovery
4. Test data integrity
5. Notify team of recovery

## Cost Optimization

### Estimated Monthly Costs
- **Supabase (Database):** $25-100 depending on usage
- **Vercel (Hosting):** $0-20 depending on traffic
- **Total:** $25-120/month

To optimize costs:
1. Use database pooling for high connection volumes
2. Archive old bulk import records
3. Optimize query efficiency
4. Monitor storage usage
