# Migration Guide: Google Sheets to Supabase

## Overview

This guide walks through migrating from Google Sheets-based data storage to Supabase as the single source of truth.

## What Changed

### Removed
- `/lib/google-sheets/` directory (client.ts, fetchCreators.ts)
- All Google Sheets environment variables (12 vars)
- googleapis dependency
- Google Sheets documentation files
- Demo mode fallback authentication

### Added
- Supabase as primary database (6 tables)
- Role-based access control (RBAC) via Supabase Auth
- Bulk import API for CSV uploads
- Data fetching modules for creators, campaigns, payouts
- Row-level security (RLS) policies

## Migration Steps

### Step 1: Set Up Supabase Database

1. Go to your Supabase project dashboard
2. Open SQL Editor
3. Run `/supabase/schema.sql` to create all tables and indexes
4. Run `/supabase/rls_policies.sql` to enable RLS and set up policies

### Step 2: Create User Accounts

Call the auth setup endpoint:
```bash
curl -X POST https://your-app.vercel.app/api/auth/setup
```

This creates three accounts:
- f12x.studio@gmail.com (editor)
- sheik.farooq@pushowl.com (client)
- ajayracharla20001@gmail.com (editor)

### Step 3: Import Existing Creator Data

If you have existing creator data in Google Sheets:

1. Export Google Sheet as CSV
2. Adjust CSV to match required format (see SUPABASE_SETUP.md)
3. Use bulk import API or upload via dashboard
4. Verify all creators imported successfully

Example CSV import:
```bash
curl -X POST https://your-app.vercel.app/api/import-creators \
  -F "file=@creators.csv" \
  -F "campaignId=campaign-123" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Step 4: Update Application Code

The following environment variables are no longer needed:
- GOOGLE_SHEETS_TYPE
- GOOGLE_SHEETS_PROJECT_ID
- GOOGLE_SHEETS_PRIVATE_KEY_ID
- GOOGLE_SHEETS_PRIVATE_KEY
- GOOGLE_SHEETS_CLIENT_EMAIL
- GOOGLE_SHEETS_CLIENT_ID
- GOOGLE_SHEETS_AUTH_URI
- GOOGLE_SHEETS_TOKEN_URI
- GOOGLE_SHEETS_AUTH_PROVIDER_CERT_URL
- GOOGLE_SHEETS_CLIENT_CERT_URL
- GOOGLE_SHEETS_SPREADSHEET_ID
- GOOGLE_SHEETS_RANGE

Required Supabase variables:
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
```

### Step 5: Verify Data Access

1. Log in with each test account
2. Verify you see the correct data based on role
3. Test bulk import with a small CSV file
4. Verify creator metrics display correctly

## Data Structure Mapping

### Google Sheets Columns → Supabase creators Table

| Google Sheets | Supabase | Type |
|---|---|---|
| ID | id | UUID |
| Campaign ID | campaign_id | UUID |
| Creator Name | creator_name | TEXT |
| Platform | platform | TEXT |
| Deliverable | deliverable | TEXT |
| Status | approval_status | TEXT |
| Progress Score | progress_score | INTEGER |
| Live Date | live_date | DATE |
| Video Link | video_link | TEXT |
| Published Link | published_video_link | TEXT |
| Views | views | INTEGER |
| Engagement Rate | engagement_rate | DECIMAL |
| Spend | spend | DECIMAL |
| Payout Status | (in payouts table) | TEXT |
| Payout Amount | (in payouts table) | DECIMAL |
| Followers | followers | INTEGER |
| Total Reach | total_reach | INTEGER |

## Benefits of Supabase Migration

### Performance
- Direct database queries (no API rate limits)
- 5-minute server-side caching
- Optimized indexes on frequently queried columns
- Pagination reduces frontend load

### Security
- Row-level security at database level
- Role-based access control (admin, editor, client)
- No more demo credentials
- Audit trail via created_at and imported_by

### Scalability
- PostgreSQL supports unlimited data
- Real-time subscriptions available
- Bulk import handles thousands of records
- Separate payout and engagement tracking tables

### Maintainability
- Single source of truth (Supabase)
- Clear data relationships
- Standardized data fetching modules
- Comprehensive error handling

## Rollback Plan

If needed to revert to Google Sheets:

1. Keep Google Sheets as backup during transition
2. Maintain both systems in parallel for 1-2 weeks
3. Once verified, remove Google Sheets environment variables
4. Archive Google Sheet for historical reference

## Support

For issues during migration:
- Check `/docs/SUPABASE_SETUP.md` for detailed setup
- Review browser console for error messages
- Check Supabase dashboard for RLS policy violations
- Verify CSV format in bulk import errors

## Timeline

- **Week 1**: Set up Supabase schema, create users
- **Week 2**: Import existing data, verify access
- **Week 3**: Test bulk imports, edge cases
- **Week 4**: Monitor performance, optimize if needed
- **Week 5+**: Production deployment, monitoring
