# F12X Magicfit Dashboard - Database Schema

## Overview
This document describes the Supabase PostgreSQL schema for the F12X Magicfit client portal.

## Tables

### 1. profiles
User profile management with role-based access control.

**Table Definition:**
```sql
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('client', 'editor')),
  first_name TEXT,
  last_name TEXT,
  company_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**RLS Policies:**
- Users can view their own profile
- Editors can view all profiles
- Only admins can insert/update profiles

### 2. creators
Creator data synced from Google Sheets.

**Table Definition:**
```sql
CREATE TABLE creators (
  id TEXT PRIMARY KEY,
  campaign_id TEXT,
  creator_name TEXT NOT NULL,
  platform TEXT CHECK (platform IN ('Instagram', 'TikTok', 'YouTube')),
  deliverable TEXT,
  approval_status TEXT DEFAULT 'Ideation',
  progress_score INTEGER DEFAULT 0,
  live_date DATE,
  video_link TEXT,
  published_video_link TEXT,
  views INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5,2) DEFAULT 0,
  spend INTEGER DEFAULT 0,
  payout_status TEXT CHECK (payout_status IN ('pending', 'processing', 'paid', 'hold')),
  payout_amount INTEGER,
  followers INTEGER,
  total_reach INTEGER,
  last_synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**RLS Policies:**
- All authenticated users can view creators
- Only editors can insert/update/delete creators
- Use timestamp triggers for audit trail

### 3. campaigns
Campaign metadata and tracking.

**Table Definition:**
```sql
CREATE TABLE campaigns (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  brand_name TEXT,
  description TEXT,
  status TEXT DEFAULT 'active',
  budget DECIMAL(10,2),
  start_date DATE,
  end_date DATE,
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4. audit_logs
Track all important actions for security and compliance.

**Table Definition:**
```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id),
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  changes JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Indexes

**For Performance:**
```sql
CREATE INDEX idx_creators_approval_status ON creators(approval_status);
CREATE INDEX idx_creators_platform ON creators(platform);
CREATE INDEX idx_creators_payout_status ON creators(payout_status);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);
```

## Row Level Security (RLS)

All tables use RLS policies. Example for creators table:

**View Policy:**
```sql
CREATE POLICY creators_view ON creators
  FOR SELECT
  USING (auth.role() = 'authenticated');
```

**Update Policy (Editors Only):**
```sql
CREATE POLICY creators_update ON creators
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'editor'
    )
  );
```

## User Roles

### Client Role
- View creators and campaigns
- View payout status for creators they're associated with
- Cannot modify any data
- Access to: Dashboard, Creators, Analytics

### Editor Role
- Full access to creators management
- Can upload/import creator data
- Can manage payouts and status updates
- Can manage other users
- Access to: All pages including Settings

## Data Validation

### Enum Values
- **Platforms:** Instagram, TikTok, YouTube
- **Status:** Ideation, Script Sent, Video Pending Approval, Revisions Requested, Approved, Published
- **Payout Status:** pending, processing, paid, hold
- **Roles:** client, editor

### Constraints
- Email must be unique
- Engagement rate: 0-100
- Progress score: 0-100
- All monetary values: non-negative

## Backup & Recovery

- Automatic daily backups via Supabase
- Point-in-time recovery available for 7 days
- Export creators table weekly to Google Sheets as backup

## Migration Scripts

When deploying changes:

1. Create new columns (non-breaking)
2. Backfill data if needed
3. Add RLS policies
4. Create indexes
5. Test thoroughly before production release

## Caching Strategy

- Creators data: 5-minute cache
- Profiles: Cached in session
- Campaigns: 1-hour cache
- Audit logs: Never cached (real-time)

## Monitoring

Key metrics to track:
- Query performance (queries >100ms)
- Row count per table
- RLS policy performance
- Audit log growth
