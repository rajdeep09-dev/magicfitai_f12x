# Supabase Architecture Guide

## Overview

The F12X Magicfit Dashboard is built entirely on Supabase for authentication and data storage. This document outlines the complete architecture, data flow, and best practices.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     Client (Browser)                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │   Login      │  │  Dashboard   │  │   Creator    │       │
│  │   Page       │  │   Page       │  │   Import     │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
┌──────────────┐  ┌──────────────────┐  ┌──────────────┐
│  useAuth()   │  │ Data Modules     │  │ API Routes   │
│  Hook        │  │ (creators.ts,    │  │ (/api/...)   │
│              │  │  payouts.ts, etc)│  │              │
└──────────────┘  └──────────────────┘  └──────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
   ┌─────────┐  ┌───────────────┐  ┌─────────────┐
   │ Auth    │  │  Supabase     │  │  RLS        │
   │ Service │  │  PostgreSQL   │  │  Policies   │
   │         │  │  Database     │  │             │
   └─────────┘  └───────────────┘  └─────────────┘
```

## Database Schema

### Tables

#### 1. Profiles Table
Extends Supabase `auth.users` table with user-specific data.

```sql
Table: profiles
├── id (UUID) - Primary key, references auth.users(id)
├── email (TEXT) - User email address
├── first_name (TEXT) - User's first name
├── company_name (TEXT) - Company/organization name
├── role (TEXT) - 'admin', 'editor', or 'client'
├── is_active (BOOLEAN) - Account status
├── created_at (TIMESTAMP)
└── updated_at (TIMESTAMP)
```

#### 2. Campaigns Table
Tracks marketing campaigns and their metadata.

```sql
Table: campaigns
├── id (UUID) - Primary key
├── name (TEXT) - Campaign name
├── description (TEXT) - Campaign details
├── status (TEXT) - 'planning', 'active', 'paused', 'completed'
├── budget (DECIMAL) - Campaign budget
├── start_date (DATE) - Campaign start
├── end_date (DATE) - Campaign end
├── created_by (UUID) - References profiles(id)
├── created_at (TIMESTAMP)
└── updated_at (TIMESTAMP)
```

#### 3. Creators Table
Main table storing all creator information.

```sql
Table: creators
├── id (UUID) - Primary key
├── campaign_id (UUID) - References campaigns(id)
├── creator_name (TEXT) - Creator's username/name
├── platform (TEXT) - 'Instagram', 'TikTok', 'YouTube'
├── deliverable (TEXT) - Content description
├── approval_status (TEXT) - Status: Ideation, Script Sent, Video Pending Approval, etc.
├── progress_score (INTEGER 0-100) - Campaign progress
├── live_date (DATE) - Content go-live date
├── video_link (TEXT) - Link to video asset
├── published_video_link (TEXT) - Published content link
├── views (INTEGER) - Video views
├── engagement_rate (DECIMAL) - Engagement percentage
├── followers (INTEGER) - Creator's follower count
├── total_reach (INTEGER) - Total audience reach
├── spend (DECIMAL) - Campaign spend per creator
├── created_at (TIMESTAMP)
└── updated_at (TIMESTAMP)
```

#### 4. Payouts Table
Tracks payment information for creators.

```sql
Table: payouts
├── id (UUID) - Primary key
├── creator_id (UUID) - References creators(id)
├── campaign_id (UUID) - References campaigns(id)
├── amount (DECIMAL) - Payout amount
├── status (TEXT) - 'pending', 'processing', 'paid', 'hold'
├── due_date (DATE) - Payment due date
├── paid_date (DATE) - Actual payment date
├── notes (TEXT) - Payment notes
├── created_at (TIMESTAMP)
└── updated_at (TIMESTAMP)
```

#### 5. Creator Engagements Table
Time-series data for engagement metrics.

```sql
Table: creator_engagements
├── id (UUID) - Primary key
├── creator_id (UUID) - References creators(id)
├── metric_date (DATE) - Date of metric
├── followers (INTEGER) - Follower count on date
├── likes_count (INTEGER) - Daily likes
├── comments_count (INTEGER) - Daily comments
├── shares_count (INTEGER) - Daily shares
├── impressions (INTEGER) - Daily impressions
├── engagement_rate (DECIMAL) - Calculated engagement
├── created_at (TIMESTAMP)
└── updated_at (TIMESTAMP)
```

#### 6. Bulk Imports Table
Tracks creator bulk import operations.

```sql
Table: bulk_imports
├── id (UUID) - Primary key
├── import_name (TEXT) - Import name/description
├── file_name (TEXT) - Original CSV filename
├── total_records (INTEGER) - Total rows in file
├── successful_records (INTEGER) - Successfully imported
├── failed_records (INTEGER) - Failed imports
├── status (TEXT) - 'pending', 'processing', 'completed', 'failed'
├── error_log (TEXT) - Detailed error messages
├── imported_by (UUID) - References profiles(id)
├── created_at (TIMESTAMP)
└── updated_at (TIMESTAMP)
```

## Row-Level Security (RLS) Policies

### Overview
All tables have RLS enabled with policies that restrict data access based on user roles.

### Key Policies

#### Profiles
- Users can view their own profile
- Editors/admins can view all profiles
- Only admins can insert profiles

#### Campaigns
- Editors/admins can view all campaigns
- Clients can only view campaigns they created

#### Creators
- All authenticated users can view creators
- Only editors can create/modify creators

#### Payouts
- Only editors can view and manage payouts

#### Engagement Metrics
- Only editors can view metrics
- Only editors can insert new metrics

#### Bulk Imports
- Only editors can view import history
- Only editors can create new imports

## Data Flow

### Authentication Flow
```
1. User enters email/password on login page
2. Supabase Auth validates credentials
3. JWT token issued and stored in browser
4. User profile fetched from profiles table
5. User role and permissions loaded
6. User redirected to dashboard with role-based access
```

### Creator Data Fetch Flow
```
1. Component mounts (CreatorsPage)
2. useAuth hook checks authentication
3. getCreators() called with optional filters
4. Check in-memory cache (5 minute TTL)
5. If cache miss: Query Supabase creators table
6. RLS policy validates user access
7. Apply client-side filtering/sorting
8. Display paginated results (10 per page)
```

### Bulk Import Flow
```
1. Editor uploads CSV file
2. Form submission to /api/import-creators
3. Server-side validation and parsing
4. Batch insert into creators table (100 per batch)
5. BulkImport record created in imports table
6. Error tracking and status updates
7. Response with success/failure counts
8. User notified of import results
```

## Indexes for Performance

```sql
-- Creator queries
CREATE INDEX idx_creators_campaign_id ON creators(campaign_id);
CREATE INDEX idx_creators_approval_status ON creators(approval_status);
CREATE INDEX idx_creators_platform ON creators(platform);

-- Payout queries
CREATE INDEX idx_payouts_creator_id ON payouts(creator_id);
CREATE INDEX idx_payouts_status ON payouts(status);

-- Engagement analytics
CREATE INDEX idx_engagements_creator_id ON creator_engagements(creator_id);
CREATE INDEX idx_engagements_metric_date ON creator_engagements(metric_date);

-- Import tracking
CREATE INDEX idx_bulk_imports_status ON bulk_imports(status);
```

## Environment Variables

Required Supabase environment variables:
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
POSTGRES_URL=postgresql://...
POSTGRES_PRISMA_URL=postgresql://...
POSTGRES_URL_NON_POOLING=postgresql://...
```

## Authentication Methods

### Supabase Auth
- Email/password authentication
- JWT tokens issued on login
- Automatic token refresh
- Session management via HTTP-only cookies
- No Google authentication required

## Performance Characteristics

### Query Times (Typical)
- Single creator lookup: <50ms
- All creators fetch: <100ms
- Filtered creators: <150ms
- Payout status update: <80ms

### Caching
- In-memory creator cache: 5 minutes
- Component-level memoization: Session duration
- Browser cache: 1 hour for static assets

## Security Best Practices

1. **Always use RLS policies** - Never bypass with service role in client code
2. **Validate on server** - CSV imports validated server-side before insertion
3. **Error handling** - Never expose database errors to users
4. **Logging** - Log all mutations for audit trail
5. **Role-based access** - Enforce permissions at database level

## Migration from Google Sheets

### What Changed
- ❌ Google Sheets integration removed
- ❌ Google Service Account removed
- ✅ Supabase PostgreSQL as primary database
- ✅ Supabase Auth for all users
- ✅ Bulk CSV import via API instead of Sheets

### Data Migration
1. Export existing creators from Google Sheets as CSV
2. Run bulk import via `/api/import-creators`
3. Validate all records imported successfully
4. Update any campaign_id references as needed
5. Verify all payout records exist and are accurate

## Maintenance

### Regular Tasks
- Monitor database size and performance
- Review RLS policies quarterly
- Update index statistics
- Archive old bulk import records
- Review error logs for patterns

### Scaling Considerations
- Table partitioning for creator_engagements (time-based)
- Connection pooling via Supabase for high traffic
- Read replicas for analytics queries
- Archive historical data to cold storage

## Troubleshooting

### Common Issues

**"Unauthorized" error when fetching data**
- Check RLS policy allows user's role
- Verify JWT token is valid
- Ensure user profile exists in database

**Cache showing stale data**
- Call `invalidateCreatorsCache()` after mutations
- Check cache TTL hasn't been exceeded
- Force refresh with `getCreators({ forceRefresh: true })`

**Bulk import failures**
- Validate CSV format matches expected columns
- Check all required fields are present
- Review error_log in bulk_imports table
- Verify file encoding is UTF-8
