# Supabase Setup Guide

## Database Schema Setup

Run the following SQL in your Supabase SQL Editor:

### 1. Create Tables and Indexes
Copy and paste the contents of `/supabase/schema.sql` into the Supabase SQL Editor and execute.

### 2. Enable Row Level Security (RLS)
Copy and paste the contents of `/supabase/rls_policies.sql` into the Supabase SQL Editor and execute.

## User Authentication Setup

### Create User Accounts

Call the setup endpoint to create the three user accounts:

```bash
curl -X POST https://your-app.vercel.app/api/auth/setup
```

This creates:
- f12x.studio@gmail.com (Editor role)
- sheik.farooq@pushowl.com (Client role)
- ajayracharla20001@gmail.com (Editor role)

All with password: F12XMAGICFIT

### Required Environment Variables

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

## Data Structure

### Creators Table
- id (UUID)
- campaign_id (UUID) - Foreign key to campaigns
- creator_name (TEXT) - Creator's name
- platform (TEXT) - Instagram, TikTok, or YouTube
- followers (INTEGER) - Follower count
- engagement_rate (DECIMAL) - Engagement percentage
- approval_status (TEXT) - Ideation, Script Sent, Video Pending Approval, Revisions Requested, Approved, Published
- progress_score (INTEGER) - 0-100
- views (INTEGER)
- spend (DECIMAL)
- total_reach (INTEGER)
- Additional fields: email, phone, deliverable, live_date, video_link, published_video_link, notes

### Campaigns Table
- id (UUID)
- name (TEXT)
- description (TEXT)
- status (TEXT) - active, pending, completed, cancelled
- start_date (DATE)
- end_date (DATE)
- budget (DECIMAL)
- created_by (UUID) - Reference to profiles

### Payouts Table
- id (UUID)
- creator_id (UUID)
- campaign_id (UUID)
- amount (DECIMAL)
- status (TEXT) - pending, processing, paid, hold, rejected
- payment_method (TEXT)
- payment_date (DATE)
- notes (TEXT)

### Profiles Table
- id (UUID) - Matches auth.users.id
- email (TEXT)
- first_name (TEXT)
- company_name (TEXT)
- role (TEXT) - admin, editor, client
- avatar_url (TEXT)

### Bulk Imports Table
- id (UUID)
- imported_by (UUID)
- campaign_id (UUID)
- total_records (INTEGER)
- successful_records (INTEGER)
- failed_records (INTEGER)
- status (TEXT) - pending, processing, completed, failed
- file_name (TEXT)
- error_log (JSONB)

## CSV Import Format

For bulk creator imports, use the following CSV header:

```
creator_name,platform,followers,engagement_rate,email,phone,deliverable,approval_status,progress_score,live_date,video_link,published_video_link,views,spend,total_reach,campaign_id
```

Required fields:
- creator_name
- platform (Instagram, TikTok, or YouTube)
- campaign_id

Optional fields:
- followers (default: 0)
- engagement_rate (default: 0.00)
- email
- phone
- deliverable
- approval_status (default: Ideation)
- progress_score (default: 0)
- live_date
- video_link
- published_video_link
- views (default: 0)
- spend (default: 0.00)
- total_reach (default: 0)

## Data Fetching Modules

### Creators Module (`lib/supabase/creators.ts`)
```typescript
import { getCreators, createCreator, updateCreator, deleteCreator } from '@/lib/supabase/creators';

// Fetch creators with caching
const creators = await getCreators({ campaignId: 'campaign-123' });

// Create new creator
const newCreator = await createCreator({
  campaign_id: 'campaign-123',
  creator_name: '@influencer',
  platform: 'Instagram',
  // ... other fields
});

// Update creator
await updateCreator(creatorId, { approval_status: 'Published' });

// Delete creator
await deleteCreator(creatorId);
```

### Campaigns Module (`lib/supabase/campaigns.ts`)
```typescript
import { getCampaigns, getCampaignById, createCampaign } from '@/lib/supabase/campaigns';

// Fetch campaigns
const campaigns = await getCampaigns({ status: 'active' });

// Create campaign
const campaign = await createCampaign({
  name: 'Summer Campaign 2026',
  status: 'active',
  start_date: '2026-05-11',
  end_date: '2026-08-31',
  created_by: userId,
});
```

### Payouts Module (`lib/supabase/payouts.ts`)
```typescript
import { getPayouts, updatePayoutStatus } from '@/lib/supabase/payouts';

// Fetch payouts
const payouts = await getPayouts({ campaignId: 'campaign-123', status: 'pending' });

// Update payout status
await updatePayoutStatus(payoutId, 'paid');
```

### Bulk Imports Module (`lib/supabase/imports.ts`)
```typescript
import { createBulkImport, updateBulkImportStatus, getBulkImports } from '@/lib/supabase/imports';

// Create import record
const importRecord = await createBulkImport({
  imported_by: userId,
  campaign_id: 'campaign-123',
  total_records: 150,
  successful_records: 0,
  failed_records: 0,
  status: 'processing',
  file_name: 'creators.csv',
});

// Update after processing
await updateBulkImportStatus(importRecord.id, 'completed', {
  successful_records: 145,
  failed_records: 5,
});
```

## Bulk Creator Import

### Using the Import API

```typescript
const formData = new FormData();
formData.append('file', csvFile);
formData.append('campaignId', campaignId);
formData.append('importName', 'April 2026 Batch');

const response = await fetch('/api/import-creators', {
  method: 'POST',
  body: formData,
});

const result = await response.json();
// result.success: boolean
// result.importId: string
// result.totalRecords: number
// result.successCount: number
// result.failureCount: number
// result.errors: Array<{ row: number; error: string }>
```

## Role-Based Access Control

The application uses JWT claims and RLS policies to enforce role-based access:

### Admin Role
- Full access to all data
- Can create, read, update, delete all resources
- Can manage user accounts

### Editor Role
- Can create, read, update, delete creators
- Can manage campaigns and payouts
- Can perform bulk imports
- Cannot manage user accounts

### Client Role
- Can only read approved/published creators
- Can only view their own campaign data
- Cannot modify data

## Performance Optimization

### Caching Strategy
- 5-minute server-side cache for creators, campaigns, payouts
- Cache is invalidated on any create/update/delete operation
- Client-side data fetching uses Supabase's realtime subscriptions when needed

### Database Indexes
All tables have indexes on frequently queried columns:
- campaign_id (creators, payouts)
- approval_status (creators)
- platform (creators)
- status (payouts, campaigns, bulk_imports)

### Lazy Loading
- Components use React.memo for memoization
- Pages use dynamic imports for heavy components
- Pagination (10 items per page) reduces DOM nodes

## Troubleshooting

### "Row-level security" errors
- Ensure the user has the correct role in the profiles table
- Check RLS policies match the user's role
- Verify Supabase auth is working correctly

### Import failures
- Validate CSV format matches the expected structure
- Check required fields are present: creator_name, platform, campaign_id
- Review error logs in the bulk_imports table

### Data not loading
- Check browser console for detailed error messages
- Verify Supabase credentials in environment variables
- Ensure user is authenticated and has correct role permissions

## Security Notes

- Never expose SUPABASE_SERVICE_ROLE_KEY in client-side code
- Use RLS policies to enforce data access at the database level
- All user data is encrypted in transit (HTTPS)
- Audit trail maintained via created_at timestamps and imported_by tracking
