# Role Recognition Fix - Complete Setup Guide

## Problem
The system is not recognizing who is an editor and who is a client. Users are not being properly identified by their role.

## Root Causes
1. **Supabase Schema Not Deployed** - The database tables need to be created with proper constraints and indexes
2. **Users Not Created** - The three user accounts haven't been created in Supabase Auth
3. **Profile Records Missing** - Even if auth users exist, their profile records with role data may not be created
4. **Email Recognition Issue** - Profile.email may not match auth.users.email due to case sensitivity or formatting

## Step-by-Step Fix

### Step 1: Deploy Database Schema (One-Time Setup)

Run these SQL migrations in Supabase SQL Editor in this exact order:

**1a. Deploy Initial Schema**
- Copy and paste entire contents of `/supabase/schema.sql`
- Execute in Supabase SQL Editor

**1b. Deploy RLS Policies**
- Copy and paste entire contents of `/supabase/rls_policies.sql`
- Execute in Supabase SQL Editor

**1c. Fix Profiles Table**
- Copy and paste entire contents of `/supabase/migration_fix_profiles_table.sql`
- Execute in Supabase SQL Editor

### Step 2: Create User Accounts

Make a POST request to your application's setup endpoint:

```
POST /api/auth/setup
```

This endpoint:
- Creates three users in Supabase Auth with confirmed emails:
  - f12x.studio@gmail.com (editor role)
  - sheik.farooq@pushowl.com (client role)
  - ajayracharla20001@gmail.com (editor role)
- Creates profile records for each user with the correct role
- Returns success/error status for each user

**Expected Response:**
```json
{
  "success": true,
  "results": [
    { "email": "f12x.studio@gmail.com", "status": "success", "role": "editor" },
    { "email": "sheik.farooq@pushowl.com", "status": "success", "role": "client" },
    { "email": "ajayracharla20001@gmail.com", "status": "success", "role": "editor" }
  ]
}
```

### Step 3: Verify Role Recognition

1. Log in with f12x.studio@gmail.com / F12XMAGICFIT
2. Check Header component - should display "👨‍💼 Editor"
3. Settings menu should appear (only visible to editors)
4. Log out and log in with sheik.farooq@pushowl.com / F12XMAGICFIT
5. Check Header component - should display "👤 Client"
6. Settings menu should NOT appear (client role doesn't have it)

### Step 4: How Role Recognition Works

**Flow:**
1. User logs in via `/auth/login` page with email/password
2. Supabase Auth validates credentials
3. `useAuth()` hook calls `supabase.auth.getUser()` to get authenticated user
4. Hook queries `profiles` table WHERE `id = user.id` to fetch role data
5. Hook sets `profile.role` = 'editor' | 'client' | 'admin'
6. Header component uses `isEditor = profile?.role === 'editor' || profile?.role === 'admin'`
7. Conditional navigation appears/disappears based on isEditor flag

**Email Matching:**
- `auth.users.email` - Email from Supabase Auth (source of truth for login)
- `profiles.email` - Email stored in profiles table (should match exactly)
- `creators.email` - Optional contact email for creators (separate from user email)

### Step 5: Troubleshooting

**Issue: Role badge still shows as Client when logging in as Editor**
- Verify profile was created: Check Supabase Dashboard > profiles table
- Verify email matches exactly: `auth.users.email` must equal `profiles.email`
- Clear browser cookies and log in again
- Check browser console for errors in useAuth hook

**Issue: Settings menu doesn't appear for editors**
- Header component checks `isEditor` flag from useAuth hook
- If profile.role is not 'editor', isEditor will be false
- Verify profiles table has correct role value

**Issue: Can't log in at all**
- Verify users were created successfully from /api/auth/setup response
- Check Supabase Dashboard > Auth > Users tab to see created users
- Check SUPABASE_SERVICE_ROLE_KEY is set in environment variables

**Issue: Profile not loading**
- Check RLS policies allow user to read their own profile
- Profile SELECT policy: `auth.uid() = id` should be true
- Verify profiles table has data for the logged-in user ID

### Step 6: Database Structure Reference

**profiles table columns:**
- `id` (UUID) - References auth.users(id)
- `email` (TEXT) - User email (should match auth.users.email)
- `first_name` (TEXT) - User first name
- `company_name` (TEXT) - User company
- `role` (TEXT) - 'admin' | 'editor' | 'client'
- `is_active` (BOOLEAN) - User active status
- `email_verified` (BOOLEAN) - Email verification status
- `created_at` (TIMESTAMP) - Profile creation time
- `updated_at` (TIMESTAMP) - Last profile update time

### Step 7: Validate Everything Works

Test these scenarios:

**Editor Login Test:**
```
Email: f12x.studio@gmail.com
Password: F12XMAGICFIT
Expected: Header shows "👨‍💼 Editor", Settings appears, all editor features available
```

**Client Login Test:**
```
Email: sheik.farooq@pushowl.com
Password: F12XMAGICFIT
Expected: Header shows "👤 Client", Settings hidden, client-only view
```

**Creator Management:**
- Editors: Can create, approve, revise creators
- Clients: Can only view approved creators
- Both: Can see engagement metrics

## Environment Variables Required

```
NEXT_PUBLIC_SUPABASE_URL=https://perzvdtfzddyhnnuovnq.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_e1I5Y1RJlPwr_aalqtojpw_YCwzxsLw
SUPABASE_SERVICE_ROLE_KEY=[Your service role key - needed for /api/auth/setup]
```

## Key Code Locations

- **useAuth Hook:** `/hooks/useAuth.ts` - Fetches user and profile data
- **Header Component:** `/components/Header.tsx` - Uses isEditor to conditionally show Settings
- **Auth Setup API:** `/app/api/auth/setup/route.ts` - Creates users and profiles
- **RLS Policies:** `/supabase/rls_policies.sql` - Enforces role-based access
- **Schema:** `/supabase/schema.sql` - Defines profiles table structure

## Summary

Role recognition requires:
1. ✅ Database schema deployed to Supabase
2. ✅ Users created via /api/auth/setup endpoint
3. ✅ Profile records with role data
4. ✅ Email consistency between auth.users and profiles
5. ✅ RLS policies enforcing role-based access
6. ✅ Frontend components reading role from useAuth hook

Once all steps are complete, the system will correctly identify and distinguish between editors and clients.
