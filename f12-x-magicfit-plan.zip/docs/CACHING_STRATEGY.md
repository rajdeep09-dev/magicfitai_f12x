# Caching Strategy

## Overview

This document outlines the caching strategy for the F12X Magicfit Dashboard to optimize performance while ensuring data freshness.

## Layers of Caching

### 1. Server-Side Caching (In-Memory)
- **Duration:** 5 minutes per request
- **Location:** Memory variables in data fetching modules (`creators.ts`, `payouts.ts`, etc.)
- **Strategy:** Automatic cache invalidation on mutations (create, update, delete)
- **Use Case:** Frequent reads of the same data within short intervals

### 2. Client-Side Caching (React Query Pattern)
- **Duration:** Session-based or until user navigates away
- **Strategy:** `useMemo` hooks in components prevent unnecessary recalculations
- **Use Case:** Heavy filtering and sorting operations

### 3. Browser Cache (HTTP Headers)
- **Duration:** Configurable via HTTP cache headers
- **Strategy:** Set on static assets (images, fonts, icons)
- **Use Case:** Public assets that don't change frequently

## Caching Implementation Details

### Creators Data
```typescript
// File: lib/supabase/creators.ts
- Cache TTL: 5 minutes
- Cache key: creators_{filters}
- Invalidation: On create/update/delete operations
- Fallback: Empty array on error
```

### Payouts Data
```typescript
// File: lib/supabase/payouts.ts
- No in-memory cache (frequently updated)
- Real-time queries for current status
- Fallback: Empty array on error
```

### Campaigns Data
```typescript
// File: lib/supabase/campaigns.ts
- Cache TTL: 5 minutes
- Used primarily for filtering and references
- Invalidation: On campaign status changes
```

## Cache Invalidation

### Automatic Invalidation
1. **Create Operations:** Clears creator cache immediately
2. **Update Operations:** Clears creator cache immediately
3. **Delete Operations:** Clears creator cache immediately

### Manual Invalidation
```typescript
import { invalidateCreatorsCache } from '@/lib/supabase/creators';

// Force refresh cache
invalidateCreatorsCache();
const creators = await getCreators({ forceRefresh: true });
```

## Performance Targets

| Metric | Target | Optimized By |
|--------|--------|--------------|
| First Contentful Paint (FCP) | <1.5s | Code splitting, lazy loading |
| Time to Interactive (TTI) | <2.5s | Memoization, caching |
| Lighthouse Performance | 90+ | Image optimization, bundle size |
| Bundle Size (gzipped) | <350KB | Tree-shaking, code splitting |
| API Response Time | <200ms | Database indexes, RLS optimization |

## Best Practices

1. **Always use cache when available** for read operations
2. **Invalidate cache immediately after mutations** to prevent stale data
3. **Provide user feedback** during cache refresh
4. **Monitor cache hit rates** in production
5. **Use force refresh sparingly** to avoid unnecessary load

## Monitoring

```typescript
// Enable debug logging
console.log('[v0] Returning creators from cache'); // Cache hit
console.log('[v0] Fetching creators from Supabase'); // Cache miss
```

## Future Improvements

1. Implement Redis caching for distributed systems
2. Add cache statistics dashboard
3. Implement progressive cache invalidation
4. Add service worker for offline support
