-- ============================================================================
-- F12X Magicfit Dashboard - Database Schema
-- ============================================================================
-- This migration creates the complete database schema for the application.
-- All tables use UUID primary keys and include audit timestamps.

-- ============================================================================
-- 1. PROFILES TABLE (extends Supabase auth.users)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  first_name TEXT,
  company_name TEXT,
  role TEXT NOT NULL CHECK (role IN ('admin', 'editor', 'client')) DEFAULT 'client',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- ============================================================================
-- 2. CAMPAIGNS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL CHECK (status IN ('planning', 'active', 'paused', 'completed')) DEFAULT 'planning',
  budget DECIMAL(15, 2),
  start_date DATE,
  end_date DATE,
  created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- ============================================================================
-- 3. CREATORS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.creators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID REFERENCES public.campaigns(id) ON DELETE CASCADE,
  creator_name TEXT NOT NULL,
  platform TEXT NOT NULL CHECK (platform IN ('Instagram', 'TikTok', 'YouTube')) DEFAULT 'Instagram',
  deliverable TEXT,
  approval_status TEXT NOT NULL 
    CHECK (approval_status IN ('Ideation', 'Script Sent', 'Video Pending Approval', 'Revisions Requested', 'Approved', 'Published'))
    DEFAULT 'Ideation',
  progress_score INTEGER DEFAULT 0 CHECK (progress_score >= 0 AND progress_score <= 100),
  live_date DATE,
  video_link TEXT,
  published_video_link TEXT,
  views INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5, 2) DEFAULT 0.00,
  followers INTEGER DEFAULT 0,
  total_reach INTEGER DEFAULT 0,
  spend DECIMAL(15, 2) DEFAULT 0.00,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- ============================================================================
-- 4. PAYOUTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  amount DECIMAL(15, 2) NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'processing', 'paid', 'hold')) DEFAULT 'pending',
  due_date DATE,
  paid_date DATE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- ============================================================================
-- 5. CREATOR ENGAGEMENT METRICS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.creator_engagements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  metric_date DATE NOT NULL,
  followers INTEGER DEFAULT 0,
  likes_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  shares_count INTEGER DEFAULT 0,
  impressions INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5, 2) DEFAULT 0.00,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- ============================================================================
-- 6. BULK IMPORTS TRACKING TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.bulk_imports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  import_name TEXT NOT NULL,
  file_name TEXT,
  total_records INTEGER NOT NULL DEFAULT 0,
  successful_records INTEGER NOT NULL DEFAULT 0,
  failed_records INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('pending', 'processing', 'completed', 'failed')) DEFAULT 'pending',
  error_log TEXT,
  imported_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_creators_campaign_id ON public.creators(campaign_id);
CREATE INDEX IF NOT EXISTS idx_creators_approval_status ON public.creators(approval_status);
CREATE INDEX IF NOT EXISTS idx_creators_platform ON public.creators(platform);
CREATE INDEX IF NOT EXISTS idx_payouts_creator_id ON public.payouts(creator_id);
CREATE INDEX IF NOT EXISTS idx_payouts_campaign_id ON public.payouts(campaign_id);
CREATE INDEX IF NOT EXISTS idx_payouts_status ON public.payouts(status);
CREATE INDEX IF NOT EXISTS idx_engagements_creator_id ON public.creator_engagements(creator_id);
CREATE INDEX IF NOT EXISTS idx_engagements_metric_date ON public.creator_engagements(metric_date);
CREATE INDEX IF NOT EXISTS idx_bulk_imports_status ON public.bulk_imports(status);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON public.campaigns(status);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_engagements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bulk_imports ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- PROFILES RLS POLICIES
-- ============================================================================
-- Users can read their own profile
CREATE POLICY "Profiles: Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

-- Editors and admins can view all profiles
CREATE POLICY "Profiles: Editors and admins can view all profiles"
  ON public.profiles FOR SELECT
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Users can update their own profile
CREATE POLICY "Profiles: Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Only admins can insert profiles
CREATE POLICY "Profiles: Only admins can insert profiles"
  ON public.profiles FOR INSERT
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin'
  );

-- ============================================================================
-- CAMPAIGNS RLS POLICIES
-- ============================================================================
-- Editors and admins can view all campaigns
CREATE POLICY "Campaigns: Editors and admins can view all campaigns"
  ON public.campaigns FOR SELECT
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Clients can only view campaigns they created
CREATE POLICY "Campaigns: Clients can view own campaigns"
  ON public.campaigns FOR SELECT
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'client' AND created_by = auth.uid()
  );

-- Editors can create campaigns
CREATE POLICY "Campaigns: Editors can create campaigns"
  ON public.campaigns FOR INSERT
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can update campaigns they created
CREATE POLICY "Campaigns: Editors can update campaigns"
  ON public.campaigns FOR UPDATE
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  )
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ============================================================================
-- CREATORS RLS POLICIES
-- ============================================================================
-- All authenticated users can view creators
CREATE POLICY "Creators: All users can view creators"
  ON public.creators FOR SELECT
  USING (auth.role() = 'authenticated');

-- Editors can create creators
CREATE POLICY "Creators: Editors can create creators"
  ON public.creators FOR INSERT
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can update creators
CREATE POLICY "Creators: Editors can update creators"
  ON public.creators FOR UPDATE
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  )
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ============================================================================
-- PAYOUTS RLS POLICIES
-- ============================================================================
-- Editors can view all payouts
CREATE POLICY "Payouts: Editors can view all payouts"
  ON public.payouts FOR SELECT
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can manage payouts
CREATE POLICY "Payouts: Editors can manage payouts"
  ON public.payouts FOR INSERT
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

CREATE POLICY "Payouts: Editors can update payouts"
  ON public.payouts FOR UPDATE
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  )
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ============================================================================
-- ENGAGEMENT METRICS RLS POLICIES
-- ============================================================================
-- Editors can view engagement metrics
CREATE POLICY "Engagements: Editors can view metrics"
  ON public.creator_engagements FOR SELECT
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can insert metrics
CREATE POLICY "Engagements: Editors can insert metrics"
  ON public.creator_engagements FOR INSERT
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ============================================================================
-- BULK IMPORTS RLS POLICIES
-- ============================================================================
-- Editors can view all imports
CREATE POLICY "Bulk Imports: Editors can view all imports"
  ON public.bulk_imports FOR SELECT
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can create imports
CREATE POLICY "Bulk Imports: Editors can create imports"
  ON public.bulk_imports FOR INSERT
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can update imports
CREATE POLICY "Bulk Imports: Editors can update imports"
  ON public.bulk_imports FOR UPDATE
  USING (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  )
  WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ============================================================================
-- TRIGGER FOR AUTOMATIC TIMESTAMP UPDATES
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());
  RETURN NEW;
END;
$$ LANGUAGE PLPGSQL;

-- Apply trigger to all tables with updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON public.campaigns
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_creators_updated_at BEFORE UPDATE ON public.creators
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payouts_updated_at BEFORE UPDATE ON public.payouts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_engagements_updated_at BEFORE UPDATE ON public.creator_engagements
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bulk_imports_updated_at BEFORE UPDATE ON public.bulk_imports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
