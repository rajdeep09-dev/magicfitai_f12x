-- Email Recognition and Data Consistency Migration

-- Step 1: Normalize all emails to lowercase (profiles)
UPDATE profiles
SET email = LOWER(email)
WHERE email != LOWER(email);

-- Step 2: Normalize all emails to lowercase (creators)
UPDATE creators
SET email = LOWER(email)
WHERE email IS NOT NULL AND email != LOWER(email);

-- Step 3: Create function to get user by email (case-insensitive)
CREATE OR REPLACE FUNCTION get_user_by_email(email_param TEXT)
RETURNS UUID AS $$
DECLARE
  user_id UUID;
BEGIN
  SELECT id INTO user_id
  FROM profiles
  WHERE LOWER(email) = LOWER(email_param)
  LIMIT 1;
  
  RETURN user_id;
END;
$$ LANGUAGE plpgsql STABLE;

-- Step 4: Create function to find creator by email (case-insensitive)
CREATE OR REPLACE FUNCTION find_creator_by_email(email_param TEXT, campaign_id_param UUID DEFAULT NULL)
RETURNS UUID AS $$
DECLARE
  creator_id UUID;
BEGIN
  IF campaign_id_param IS NOT NULL THEN
    SELECT id INTO creator_id
    FROM creators
    WHERE LOWER(email) = LOWER(email_param)
      AND campaign_id = campaign_id_param
    LIMIT 1;
  ELSE
    SELECT id INTO creator_id
    FROM creators
    WHERE LOWER(email) = LOWER(email_param)
    LIMIT 1;
  END IF;
  
  RETURN creator_id;
END;
$$ LANGUAGE plpgsql STABLE;

-- Step 5: Link existing creators to users by email
INSERT INTO user_creator_relationships (user_id, creator_id, relationship_type)
SELECT 
  p.id AS user_id,
  c.id AS creator_id,
  'primary_contact' AS relationship_type
FROM profiles p
INNER JOIN creators c ON LOWER(p.email) = LOWER(c.email)
WHERE p.id NOT IN (
  SELECT user_id FROM user_creator_relationships WHERE creator_id = c.id
)
ON CONFLICT (user_id, creator_id) DO NOTHING;

-- Step 6: Create email verification status column
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMP WITH TIME ZONE;

-- Step 7: Mark verified emails (from Supabase auth users)
UPDATE profiles
SET email_verified_at = NOW()
WHERE id IN (
  SELECT id FROM auth.users 
  WHERE email_confirmed_at IS NOT NULL
);

-- Step 8: Create function to validate email format
CREATE OR REPLACE FUNCTION is_valid_email(email_param TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN email_param ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Step 9: Create function to find duplicate emails
CREATE OR REPLACE FUNCTION find_duplicate_emails()
RETURNS TABLE (email TEXT, count_profiles INT, count_creators INT) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    LOWER(p.email) AS email,
    COUNT(DISTINCT p.id)::INT,
    COUNT(DISTINCT c.id)::INT
  FROM profiles p
  FULL OUTER JOIN creators c ON LOWER(p.email) = LOWER(c.email)
  WHERE p.email IS NOT NULL OR c.email IS NOT NULL
  GROUP BY LOWER(p.email)
  HAVING COUNT(DISTINCT p.id) > 1 OR COUNT(DISTINCT c.id) > 1;
END;
$$ LANGUAGE plpgsql STABLE;

-- Step 10: Add unique constraint on profiles email
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_email_unique;
ALTER TABLE profiles ADD CONSTRAINT profiles_email_unique UNIQUE (email);

-- Step 11: Create trigger for email normalization on insert/update
CREATE OR REPLACE FUNCTION normalize_email_lowercase()
RETURNS TRIGGER AS $$
BEGIN
  NEW.email := LOWER(NEW.email);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for profiles
DROP TRIGGER IF EXISTS trigger_normalize_profiles_email ON profiles;
CREATE TRIGGER trigger_normalize_profiles_email
BEFORE INSERT OR UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION normalize_email_lowercase();

-- Trigger for creators
DROP TRIGGER IF EXISTS trigger_normalize_creators_email ON creators;
CREATE TRIGGER trigger_normalize_creators_email
BEFORE INSERT OR UPDATE ON creators
FOR EACH ROW
WHEN (NEW.email IS NOT NULL)
EXECUTE FUNCTION normalize_email_lowercase();

-- Step 12: Create view for email resolution
CREATE OR REPLACE VIEW email_resolution_view AS
SELECT 
  LOWER(COALESCE(p.email, c.email)) AS email,
  p.id AS profile_user_id,
  p.email AS profile_email,
  c.id AS creator_id,
  c.creator_name,
  c.campaign_id,
  ucr.id AS relationship_id,
  CASE 
    WHEN p.email IS NOT NULL AND c.email IS NOT NULL THEN 'BOTH'
    WHEN p.email IS NOT NULL THEN 'PROFILE_ONLY'
    WHEN c.email IS NOT NULL THEN 'CREATOR_ONLY'
  END AS email_location,
  CASE 
    WHEN ucr.user_id IS NOT NULL THEN 'LINKED'
    ELSE 'UNLINKED'
  END AS relationship_status
FROM profiles p
FULL OUTER JOIN creators c ON LOWER(p.email) = LOWER(c.email)
LEFT JOIN user_creator_relationships ucr ON p.id = ucr.user_id AND c.id = ucr.creator_id
ORDER BY LOWER(COALESCE(p.email, c.email));

-- Step 13: Create function to handle email conflicts
CREATE OR REPLACE FUNCTION resolve_email_conflicts(email_to_resolve TEXT, preferred_user_id UUID DEFAULT NULL)
RETURNS TABLE (resolved BOOLEAN, message TEXT) AS $$
DECLARE
  profile_count INT;
  creator_count INT;
BEGIN
  SELECT COUNT(*) INTO profile_count FROM profiles WHERE LOWER(email) = LOWER(email_to_resolve);
  SELECT COUNT(*) INTO creator_count FROM creators WHERE LOWER(email) = LOWER(email_to_resolve);
  
  IF profile_count > 1 THEN
    RETURN QUERY SELECT FALSE, 'Multiple profiles found with this email. Manual intervention required.';
  ELSIF creator_count > 1 AND preferred_user_id IS NULL THEN
    RETURN QUERY SELECT FALSE, 'Multiple creators with this email. Specify preferred_user_id.';
  ELSE
    RETURN QUERY SELECT TRUE, 'Email conflict resolved successfully.';
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Indexes for performance on email lookups
CREATE INDEX IF NOT EXISTS idx_profiles_email_lower ON profiles(LOWER(email));
CREATE INDEX IF NOT EXISTS idx_creators_email_lower ON creators(LOWER(email));
CREATE INDEX IF NOT EXISTS idx_user_creator_rel_email ON user_creator_relationships USING btree (user_id, creator_id);
