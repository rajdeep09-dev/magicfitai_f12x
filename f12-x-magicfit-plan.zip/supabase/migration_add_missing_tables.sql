-- Migration: Add Missing Tables for Full Functionality

-- Create creator_notes table for persistent note tracking
CREATE TABLE IF NOT EXISTS creator_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES creators(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  note_text TEXT NOT NULL,
  note_type TEXT CHECK (note_type IN ('internal', 'approval', 'revision', 'general')) DEFAULT 'general',
  is_pinned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create user_creator_relationships table to link auth users with creators
CREATE TABLE IF NOT EXISTS user_creator_relationships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES creators(id) ON DELETE CASCADE,
  relationship_type TEXT CHECK (relationship_type IN ('primary_contact', 'backup_contact', 'creator')) DEFAULT 'creator',
  verified_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, creator_id)
);

-- Create approval_audit_log table for compliance and tracking
CREATE TABLE IF NOT EXISTS approval_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES creators(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK (action IN ('submitted', 'approved', 'rejected', 'revision_requested', 'revision_submitted', 'published')),
  performed_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  notes TEXT,
  previous_status TEXT,
  new_status TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create messages table for team communication
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  recipient_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  creator_id UUID REFERENCES creators(id) ON DELETE SET NULL,
  campaign_id UUID REFERENCES campaigns(id) ON DELETE SET NULL,
  subject TEXT,
  message_body TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMP WITH TIME ZONE,
  message_type TEXT CHECK (message_type IN ('direct', 'campaign_update', 'approval_notification', 'revision_request')) DEFAULT 'direct',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create conversations table for message threading
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID REFERENCES campaigns(id) ON DELETE CASCADE,
  creator_id UUID REFERENCES creators(id) ON DELETE CASCADE,
  title TEXT,
  conversation_type TEXT CHECK (conversation_type IN ('general', 'approval_workflow', 'payment_discussion')) DEFAULT 'general',
  last_message_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create conversation_participants table
CREATE TABLE IF NOT EXISTS conversation_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT CHECK (role IN ('initiator', 'participant', 'observer')) DEFAULT 'participant',
  muted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(conversation_id, user_id)
);

-- Add email index to creators table for better lookups
CREATE INDEX IF NOT EXISTS idx_creators_email ON creators(LOWER(email));
CREATE INDEX IF NOT EXISTS idx_creators_email_campaign ON creators(LOWER(email), campaign_id);

-- Add indexes for new tables
CREATE INDEX IF NOT EXISTS idx_creator_notes_creator_id ON creator_notes(creator_id);
CREATE INDEX IF NOT EXISTS idx_creator_notes_campaign_id ON creator_notes(campaign_id);
CREATE INDEX IF NOT EXISTS idx_creator_notes_created_by ON creator_notes(created_by);
CREATE INDEX IF NOT EXISTS idx_user_creator_rel_user_id ON user_creator_relationships(user_id);
CREATE INDEX IF NOT EXISTS idx_user_creator_rel_creator_id ON user_creator_relationships(creator_id);
CREATE INDEX IF NOT EXISTS idx_approval_audit_creator_id ON approval_audit_log(creator_id);
CREATE INDEX IF NOT EXISTS idx_approval_audit_campaign_id ON approval_audit_log(campaign_id);
CREATE INDEX IF NOT EXISTS idx_approval_audit_created_at ON approval_audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_recipient_id ON messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_messages_creator_id ON messages(creator_id);
CREATE INDEX IF NOT EXISTS idx_messages_is_read ON messages(is_read);
CREATE INDEX IF NOT EXISTS idx_conversations_campaign_id ON conversations(campaign_id);
CREATE INDEX IF NOT EXISTS idx_conversation_participants_user_id ON conversation_participants(user_id);
CREATE INDEX IF NOT EXISTS idx_conversation_participants_conv_id ON conversation_participants(conversation_id);

-- Enable RLS on new tables
ALTER TABLE creator_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_creator_relationships ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_participants ENABLE ROW LEVEL SECURITY;

-- Add constraints for data integrity
ALTER TABLE profiles ADD CONSTRAINT email_lowercase CHECK (email = LOWER(email));
ALTER TABLE creators ADD CONSTRAINT email_lowercase_creators CHECK (email IS NULL OR email = LOWER(email));

-- Add NOT NULL constraint to profiles email
ALTER TABLE profiles ALTER COLUMN email SET NOT NULL;
