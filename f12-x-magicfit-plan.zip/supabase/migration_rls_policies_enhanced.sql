-- Enhanced RLS Policies for Creator Notes, Messages, and Approval Tracking

-- ===== CREATOR NOTES POLICIES =====
-- Creator notes should be readable by admins, editors, and the note creator
CREATE POLICY "creator_notes_select_admin_editor" ON creator_notes
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Creator notes can be inserted by admins, editors, and the creator's assigned user
CREATE POLICY "creator_notes_insert_admin_editor" ON creator_notes
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    AND created_by = auth.uid()
  );

-- Creator notes can be updated by the creator or admins
CREATE POLICY "creator_notes_update_admin_creator" ON creator_notes
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    OR created_by = auth.uid()
  );

-- Creator notes should not be deleted (audit trail)
CREATE POLICY "creator_notes_no_delete" ON creator_notes
  FOR DELETE USING (FALSE);

-- ===== USER CREATOR RELATIONSHIPS POLICIES =====
-- Only admins and editors can view creator relationships
CREATE POLICY "user_creator_rel_select_admin_editor" ON user_creator_relationships
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    OR user_id = auth.uid()
  );

-- Only admins can create relationships
CREATE POLICY "user_creator_rel_insert_admin" ON user_creator_relationships
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Only admins can update relationships
CREATE POLICY "user_creator_rel_update_admin" ON user_creator_relationships
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- ===== APPROVAL AUDIT LOG POLICIES =====
-- Only admins and editors can view audit logs
CREATE POLICY "approval_audit_select_admin_editor" ON approval_audit_log
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Only admins can insert audit logs (normally system-generated)
CREATE POLICY "approval_audit_insert_admin" ON approval_audit_log
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Audit logs cannot be updated or deleted
CREATE POLICY "approval_audit_no_update" ON approval_audit_log
  FOR UPDATE USING (FALSE);

CREATE POLICY "approval_audit_no_delete" ON approval_audit_log
  FOR DELETE USING (FALSE);

-- ===== MESSAGES POLICIES =====
-- Users can select their own messages
CREATE POLICY "messages_select_own" ON messages
  FOR SELECT USING (
    sender_id = auth.uid() 
    OR recipient_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Users can insert messages they are sending
CREATE POLICY "messages_insert_own" ON messages
  FOR INSERT WITH CHECK (
    sender_id = auth.uid()
  );

-- Users can update their own messages (mark as read)
CREATE POLICY "messages_update_own" ON messages
  FOR UPDATE USING (
    recipient_id = auth.uid() 
    OR sender_id = auth.uid()
  );

-- Messages should not be deleted (maintain history)
CREATE POLICY "messages_no_delete" ON messages
  FOR DELETE USING (FALSE);

-- ===== CONVERSATIONS POLICIES =====
-- Participants can view conversations they're part of
CREATE POLICY "conversations_select_participants" ON conversations
  FOR SELECT USING (
    id IN (
      SELECT conversation_id FROM conversation_participants 
      WHERE user_id = auth.uid()
    )
    OR (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Admins and editors can create conversations
CREATE POLICY "conversations_insert_admin_editor" ON conversations
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Conversation creators and admins can update
CREATE POLICY "conversations_update_admin" ON conversations
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ===== CONVERSATION PARTICIPANTS POLICIES =====
-- Users can see who is in conversations they're part of
CREATE POLICY "conv_participants_select" ON conversation_participants
  FOR SELECT USING (
    user_id = auth.uid()
    OR conversation_id IN (
      SELECT conversation_id FROM conversation_participants 
      WHERE user_id = auth.uid()
    )
    OR (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Only admins can add participants
CREATE POLICY "conv_participants_insert_admin" ON conversation_participants
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Admins can update, users can update their own mute status
CREATE POLICY "conv_participants_update" ON conversation_participants
  FOR UPDATE USING (
    user_id = auth.uid()
    OR (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- ===== OPTIMIZE EXISTING CREATORS TABLE RLS =====
-- Ensure creators data is readable by authorized users
DROP POLICY IF EXISTS "creators_select" ON creators;
CREATE POLICY "creators_select_authorized" ON creators
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    OR id IN (
      SELECT creator_id FROM user_creator_relationships 
      WHERE user_id = auth.uid()
    )
  );

-- Editors can insert creators
DROP POLICY IF EXISTS "creators_insert" ON creators;
CREATE POLICY "creators_insert_editor" ON creators
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Editors can update creators
DROP POLICY IF EXISTS "creators_update" ON creators;
CREATE POLICY "creators_update_editor" ON creators
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- ===== OPTIMIZE CAMPAIGNS RLS =====
DROP POLICY IF EXISTS "campaigns_select" ON campaigns;
CREATE POLICY "campaigns_select_authorized" ON campaigns
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    OR created_by = auth.uid()
  );

-- Editors can insert campaigns
DROP POLICY IF EXISTS "campaigns_insert" ON campaigns;
CREATE POLICY "campaigns_insert_editor" ON campaigns
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Campaign creators and admins can update
DROP POLICY IF EXISTS "campaigns_update" ON campaigns;
CREATE POLICY "campaigns_update_admin_creator" ON campaigns
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    OR created_by = auth.uid()
  );

-- ===== OPTIMIZE PAYOUTS RLS =====
DROP POLICY IF EXISTS "payouts_select" ON payouts;
CREATE POLICY "payouts_select_admin_editor" ON payouts
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

-- Only admins can modify payouts
DROP POLICY IF EXISTS "payouts_insert" ON payouts;
CREATE POLICY "payouts_insert_admin" ON payouts
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

DROP POLICY IF EXISTS "payouts_update" ON payouts;
CREATE POLICY "payouts_update_admin" ON payouts
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- ===== BULK IMPORTS RLS =====
DROP POLICY IF EXISTS "bulk_imports_select" ON bulk_imports;
CREATE POLICY "bulk_imports_select_admin_editor" ON bulk_imports
  FOR SELECT USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
    OR imported_by = auth.uid()
  );

CREATE POLICY "bulk_imports_insert_editor" ON bulk_imports
  FOR INSERT WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin', 'editor')
  );

CREATE POLICY "bulk_imports_update_admin" ON bulk_imports
  FOR UPDATE USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );
