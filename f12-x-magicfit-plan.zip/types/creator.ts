export interface Creator {
  id: string;
  campaign_id: string | null;
  creator_name: string;
  platform: 'Instagram' | 'TikTok' | 'YouTube';
  deliverable: string;
  approval_status: 'Ideation' | 'Script Sent' | 'Video Pending Approval' | 'Revisions Requested' | 'Approved' | 'Published';
  progress_score: number;
  live_date: string | null;
  video_link: string;
  published_video_link?: string;
  views: number;
  engagement_rate: number;
  followers: number;
  total_reach: number;
  spend: number;
  created_at: string;
  updated_at: string;
}
