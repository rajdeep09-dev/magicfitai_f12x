'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Users, TrendingUp, DollarSign, Award } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import CreatorCard from '@/components/CreatorCard';
import CreatorFilterBar from '@/components/CreatorFilterBar';
import KPICard from '@/components/KPICard';
import { mockCreators } from '@/lib/mock-data';

interface CreatorData {
  id: string;
  creator_name: string;
  platform: 'Instagram' | 'TikTok' | 'YouTube';
  approval_status: string;
  views: number;
  engagement_rate: number;
  spend: number;
  followers?: number;
  payout_status?: 'pending' | 'paid' | 'processing';
  active_campaign?: boolean;
}

const CREATORS_PER_PAGE = 10;

export default function CreatorsPage() {
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState('');
  const [activeOnlyFilter, setActiveOnlyFilter] = useState(false);
  const [payoutFilter, setPayoutFilter] = useState('');
  const [sortBy, setSortBy] = useState('engagement');
  const [currentPage, setCurrentPage] = useState(1);

  // Enhanced mock data with additional fields
  const creatorsWithMetrics: CreatorData[] = useMemo(() => {
    return mockCreators.map((creator: any, idx: number) => ({
      ...creator,
      followers: 50000 + idx * 5000,
      payout_status: ['pending', 'paid', 'processing'][idx % 3] as 'pending' | 'paid' | 'processing',
      active_campaign: creator.approval_status !== 'Published' && creator.approval_status !== 'Script Sent',
    }));
  }, []);

  // Filter and sort logic
  const filteredCreators = useMemo(() => {
    let filtered = creatorsWithMetrics;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter((c) =>
        c.creator_name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Platform filter
    if (platformFilter) {
      filtered = filtered.filter((c) => c.platform === platformFilter);
    }

    // Active campaign filter
    if (activeOnlyFilter) {
      filtered = filtered.filter((c) => c.active_campaign);
    }

    // Payout filter
    if (payoutFilter) {
      filtered = filtered.filter((c) => c.payout_status === payoutFilter);
    }

    // Sorting
    if (sortBy === 'engagement') {
      filtered.sort((a, b) => b.engagement_rate - a.engagement_rate);
    } else if (sortBy === 'followers') {
      filtered.sort((a, b) => (b.followers || 0) - (a.followers || 0));
    } else if (sortBy === 'name') {
      filtered.sort((a, b) => a.creator_name.localeCompare(b.creator_name));
    }

    return filtered;
  }, [creatorsWithMetrics, searchQuery, platformFilter, activeOnlyFilter, payoutFilter, sortBy]);

  // Calculate KPIs
  const kpis = useMemo(() => {
    const totalApproved = creatorsWithMetrics.filter((c) => c.approval_status === 'Approved' || c.approval_status === 'Published').length;
    const activeOnCampaign = creatorsWithMetrics.filter((c) => c.active_campaign).length;
    const avgEngagement = creatorsWithMetrics.length > 0
      ? (creatorsWithMetrics.reduce((sum, c) => sum + c.engagement_rate, 0) / creatorsWithMetrics.length).toFixed(1)
      : '0';
    const totalFollowers = creatorsWithMetrics.reduce((sum, c) => sum + (c.followers || 0), 0);

    return { totalApproved, activeOnCampaign, avgEngagement, totalFollowers };
  }, [creatorsWithMetrics]);

  // Pagination logic
  const totalPages = Math.ceil(filteredCreators.length / CREATORS_PER_PAGE);
  const startIdx = (currentPage - 1) * CREATORS_PER_PAGE;
  const paginatedCreators = useMemo(
    () => filteredCreators.slice(startIdx, startIdx + CREATORS_PER_PAGE),
    [filteredCreators, currentPage]
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen bg-neutral-950 px-4 sm:px-6 lg:px-8 py-8"
    >
      {/* Hero Section */}
      <motion.section
        className="mb-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-neutral-50 mb-2">Creator Network</h1>
            <p className="text-neutral-400">Manage and monitor all approved creators and their campaign performance</p>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <KPICard
            icon={Award}
            label="Approved Creators"
            value={kpis.totalApproved}
            delay={0.1}
          />
          <KPICard
            icon={TrendingUp}
            label="Active on Campaign"
            value={kpis.activeOnCampaign}
            delay={0.2}
          />
          <KPICard
            icon={Users}
            label="Avg. Engagement Rate"
            value={`${kpis.avgEngagement}%`}
            delay={0.3}
          />
          <KPICard
            icon={DollarSign}
            label="Total Followers"
            value={`${(kpis.totalFollowers / 1000).toFixed(0)}K`}
            delay={0.4}
          />
        </div>
      </motion.section>

      {/* Filter Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <CreatorFilterBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          platformFilter={platformFilter}
          onPlatformChange={setPlatformFilter}
          activeOnlyFilter={activeOnlyFilter}
          onActiveOnlyChange={setActiveOnlyFilter}
          payoutFilter={payoutFilter}
          onPayoutChange={setPayoutFilter}
          sortBy={sortBy}
          onSortChange={setSortBy}
        />
      </motion.div>

      {/* Results Summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="mb-6"
      >
        <p className="text-sm text-neutral-400">
          Showing <span className="text-lime-400 font-semibold">{filteredCreators.length}</span> of{' '}
          <span className="text-neutral-300">{creatorsWithMetrics.length}</span> creators
        </p>
      </motion.div>

      {/* Creators Grid */}
      {filteredCreators.length > 0 ? (
        <>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            {paginatedCreators.map((creator, idx) => (
            <CreatorCard
              key={creator.id}
              id={creator.id}
              name={creator.creator_name}
              platform={creator.platform}
              followers={creator.followers || 0}
              engagementRatio={creator.engagement_rate}
              payoutStatus={creator.payout_status || 'pending'}
              activeOnCampaign={creator.active_campaign || false}
              campaignName={creator.active_campaign ? 'Magicfit Summer 2026' : undefined}
              index={idx}
            />
          ))}
          </motion.div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex items-center justify-center gap-2 mt-12"
            >
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-4 py-2 rounded-lg border border-neutral-700 text-neutral-400 hover:border-lime-400 hover:text-lime-400 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                Previous
              </button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`px-3 py-2 rounded-lg transition ${
                    currentPage === page
                      ? 'bg-lime-400 text-neutral-950 font-semibold'
                      : 'border border-neutral-700 text-neutral-400 hover:border-lime-400 hover:text-lime-400'
                  }`}
                >
                  {page}
                </button>
              ))}
              
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-4 py-2 rounded-lg border border-neutral-700 text-neutral-400 hover:border-lime-400 hover:text-lime-400 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                Next
              </button>
            </motion.div>
          )}
        </>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-neutral-900/50 backdrop-blur-md border border-neutral-800 rounded-lg p-12 text-center"
        >
          <Users className="w-12 h-12 text-neutral-600 mx-auto mb-4" />
          <p className="text-neutral-400 mb-2">No creators found matching your filters</p>
          <p className="text-sm text-neutral-500">Try adjusting your search criteria</p>
        </motion.div>
      )}
    </motion.div>
  );
}
